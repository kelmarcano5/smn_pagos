 and
 	smn_pagos.smn_orden_pago.smn_entidades_rf=${fld:smn_entidades_rf}