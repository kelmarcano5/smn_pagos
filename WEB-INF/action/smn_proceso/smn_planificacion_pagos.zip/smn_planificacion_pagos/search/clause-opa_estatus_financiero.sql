 and
 	smn_pagos.smn_orden_pago.opa_estatus_financiero=${fld:opa_estatus_financiero}