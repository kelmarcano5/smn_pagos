 and
 	smn_pagos.smn_orden_pago.smn_sucursales_rf=${fld:smn_sucursales_rf}