search();
alertBox('El estatus fue actualizado en la base de datos', 'Continuar', null, null);
