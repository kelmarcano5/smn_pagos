 and
 	smn_base.smn_mensajes.msj_fecha_registro>=${fld:msj_fecha_registro_ini}